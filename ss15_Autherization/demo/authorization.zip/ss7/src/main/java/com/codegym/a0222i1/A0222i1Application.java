package com.codegym.a0222i1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A0222i1Application {

    public static void main(String[] args) {
        SpringApplication.run(A0222i1Application.class, args);
    }

}
