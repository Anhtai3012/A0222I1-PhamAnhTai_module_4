package com.codegym.example1.service;


import com.codegym.example1.model.Category;

import java.util.List;

public interface ICategoryService {
    List<Category>findAll();
}
